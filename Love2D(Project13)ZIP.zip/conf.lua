function love.conf(t)
    -- إعدادات النافذة الأساسية
    t.window.title = "Project13(Void)"   -- عنوان النافذة
    t.window.width = 600                     -- عرض النافذة
    t.window.height = 600                     -- ارتفاع النافذة
    t.window.icon = "Models/Sprites/Icon.png"  -- أيقونة النافذة
    
    -- إعدادات متقدمة للنافذة
    t.window.resizable = false                 -- هل يمكن تغيير حجم النافذة؟
    t.window.minwidth = 600                   -- أصغر عرض مسموح
    t.window.minheight = 600                  -- أصغر ارتفاع مسموح
    t.window.fullscreen = false               -- وضع ملء الشاشة
    t.window.fullscreentype = "desktop"       -- نوع ملء الشاشة ("desktop" أو "exclusive")
    t.window.vsync = 1                        -- التزامن الرأسي (0 = غير مفعل، 1 = مفعل)
    t.window.msaa = 4                         -- مضاعفة العينات (للتخلص من الحواف المسننة)
    t.window.display = 1                      -- رقم الشاشة المستخدمة (لأنظمة متعددة الشاشات)
    
    -- إعدادات أخرى
    t.console = true                          -- عرض نافذة الكونسول (لأغراض التصحيح)
    t.version = "11.3"                        -- إصدار Love2D المستهدف
end

-- -- conf.lua
-- function love.conf(t)
--     -- إعدادات عربية
--     t.identity = "love2d_game_ar"  -- اسم مجلد الحفظ
    
--     -- إعدادات النافذة
--     t.window.title = "لعبة لوف ٢دي - منصات وقفز!"
--     t.window.width = 1280
--     t.window.height = 720
--     t.window.icon = "assets/heart_icon.png"
    
--     -- إعدادات متقدمة
--     t.window.resizable = true
--     t.window.minwidth = 800
--     t.window.minheight = 600
--     t.window.vsync = 1
--     t.window.msaa = 4
    
--     -- إعدادات التصحيح
--     t.console = true
--     t.version = "11.4"
    
--     -- تعطيل الموديولات غير المستخدمة
--     t.modules.physics = false
--     t.modules.video = false
-- end