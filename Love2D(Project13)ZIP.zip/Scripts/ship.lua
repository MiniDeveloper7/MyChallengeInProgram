local game = {}
-- local particles = {}
-- local gravity = 80 -- جاذبية

-- دالة مساعدة للتداخل الزاوي مع أقصر مسار
local function lerpAngle(a, b, t)
    local diff = (b - a) % (2 * math.pi)
    local shortest = diff > math.pi and diff - 2 * math.pi or diff
    return a + shortest * t
end

local function clampPlayerPositionWithMargin(player, margin)
    local screenWidth = love.graphics.getWidth()
    local screenHeight = love.graphics.getHeight()
    
    -- حدود أفقية مع هوامش
    player.x = math.max(margin, math.min(player.x, screenWidth - player.width / player.image:getWidth() - margin))
    
    -- حدود رأسية مع هوامش
    player.y = math.max(margin, math.min(player.y, screenHeight - player.height / player.image:getHeight() - margin))
end

local function clampPlayerPosition(player)
    -- الحصول على أبعاد الشاشة
    local screenWidth = love.graphics.getWidth()
    local screenHeight = love.graphics.getHeight()
    
    -- تحديد الحد الأيسر (لا يقل عن 0)
    if player.x < 0 then
        player.x = 0
    end
    
    -- تحديد الحد الأيمن (لا يتجاوز عرض الشاشة ناقص عرض اللاعب)
    if player.x > screenWidth - player.width then
        player.x = screenWidth - player.width
    end
    
    -- تحديد الحد الأعلى (لا يقل عن 0)
    if player.y < 0 then
        player.y = 0
    end
    
    -- تحديد الحد الأسفل (لا يتجاوز ارتفاع الشاشة ناقص ارتفاع اللاعب)
    if player.y > screenHeight - player.height then
        player.y = screenHeight - player.height
    end
end

-- local function createParticleSystem(x, y, count)
--     for i = 1, count do
--         local particle = {
--             x = x,
--             y = y,
--             size = 1, -- حجم الجسيم
--             startSize = 0, -- سيتم تعيينه لاحقاً
--             life = math.random(0.25, 1.0), -- العمر
--             maxLife = 0, -- سيتم تعيينه لاحقاً
--             color = {
--                 r = math.random(200, 255),
--                 g = math.random(0, 50),
--                 b = 0,
--                 a = 255 -- شفافية البداية
--             },
--             velocity = {
--                 x = math.random(-220, -220),
--                 y = math.random(50, 100) --love.math.random(-120, 120) -- تبدأ بالتحرك للأعلى
--             },
--             acceleration = {
--                 x = 0,
--                 y = 0 --gravity
--             }
--         }
        
--         -- حفظ القيم الأولية للاستخدام في التلاشي
--         particle.startSize = particle.size
--         particle.maxLife = particle.life
        
--         table.insert(particles, particle)
--     end
-- end

-- local function updateParticles(dt)
--     for i = #particles, 1, -1 do
--         local p = particles[i]
        
--         -- تحديث الموقع والسرعة
--         p.velocity.x = p.velocity.x + p.acceleration.x * dt
--         p.velocity.y = p.velocity.y + p.acceleration.y * dt
--         p.x = p.x + p.velocity.x * dt
--         p.y = p.y + p.velocity.y * dt
        
--         -- تحديث العمر والتلاشي
--         p.life = p.life - dt
        
--         -- حساب التغيرات التدريجية
--         local lifeRatio = p.life / p.maxLife
        
--         -- 1. تلاشي الشفافية تدريجياً
--         p.color.a = 255 * lifeRatio
        
--         -- 2. تصغير الحجم تدريجياً
--         p.size = p.startSize * lifeRatio
--         -- for i in 0, 0.1, 1 do
--             -- p.size = p.size * i
--         -- end
        
--         -- 3. تغيير اللون تدريجياً (اختياري)
--         -- p.color.g = 50 + 150 * lifeRatio
        
--         -- إزالة الجسيمات بعد انتهاء عمرها تماماً
--         if p.life <= 0 then
--             table.remove(particles, i)
--         end
--     end
-- end

-- local function drawParticles()
--     for _, p in ipairs(particles) do
--         -- تعيين اللون مع الشفافية الحالية
--         love.graphics.setColor(p.color.r, p.color.g, p.color.b, p.color.a)
        
--         -- رسم الدائرة
--         love.graphics.circle("fill", p.x, p.y, p.size)
--         love.graphics.rotate(game.player.rotation)

--         -- إضافة توهج خفيف (اختياري)
--         -- if p.size > 3 then
--             -- love.graphics.setColor(p.color.r, p.color.g, p.color.b, p.color.a * 0.3)
--             -- love.graphics.circle("fill", p.x, p.y, p.size * 1.5)
--         -- end
--     end
--     love.graphics.setColor(255, 255, 255, 255) -- إعادة تعيين اللون
-- end

----------------->

-- ======= نظام جسيمات الصاروخ ======= --
local fireParticles = {}
local smokeParticles = {}
local particleTimer = 0
local emissionRate = 0.01 -- معدل انبعاث الجسيمات

-- إنشاء جسيم نار
local function createFireParticle(player)
    -- حساب موقع المؤخرة بناءً على الدوران
    local offsetDistance = player.height / 3.65 --2 + 5
    local exhaustX = player.x - math.sin(player.rotation) * offsetDistance
    local exhaustY = player.y + math.cos(player.rotation) * offsetDistance
    
    -- حساب السرعة بناءً على اتجاه اللاعب
    local baseSpeed = love.math.random(80, 120)
    local speedVariation = love.math.random(-20, 20)
    local particleDirection = player.rotation + math.pi -- الاتجاه المعاكس
    local dirVariation = love.math.random(-10, 10) * (math.pi/180) -- ±10 درجة
    
    local particle = {
        x = exhaustX,
        y = exhaustY,
        size = math.random(1, 3),
        startSize = 0,
        life = math.random(0.4, 0.8),
        maxLife = 0,
        color = {
            r = math.random(100, 255),
            g = math.random(50, 255),
            b = 0,
            a = 255
        },
        velocity = {
            x = math.sin(particleDirection + dirVariation) * (baseSpeed + speedVariation),
            y = -math.cos(particleDirection + dirVariation) * (baseSpeed + speedVariation)
        },
        acceleration = {
            x = 0,
            y = 0
        }
    }
    
    particle.startSize = particle.size
    particle.maxLife = particle.life
    
    return particle
end

-- إنشاء جسيم دخان
local function createSmokeParticle(player)
    -- حساب موقع المؤخرة بناءً على الدوران
    local offsetDistance = player.height / 3.65 --2 + 10
    local exhaustX = player.x - math.sin(player.rotation) * offsetDistance
    local exhaustY = player.y + math.cos(player.rotation) * offsetDistance
    
    -- حساب السرعة بناءً على اتجاه اللاعب
    local baseSpeed = math.random(30, 60)
    local particleDirection = player.rotation + math.pi
    local dirVariation = math.random(-30, 30) * (math.pi/180)
    
    local particle = {
        x = exhaustX,
        y = exhaustY,
        size = math.random(3, 6),
        startSize = 0,
        life = math.random(1.0, 1.5),
        maxLife = 0,
        color = {
            r = math.random(50, 255),
            g = math.random(0, 1),
            b = 0,
            a = 200
        },
        velocity = {
            x = math.sin(particleDirection + dirVariation) * baseSpeed,
            y = -math.cos(particleDirection + dirVariation) * baseSpeed
        },
        acceleration = {
            x = 0,
            y = -20 -- دخان يرتفع قليلاً
        }
    }
    
    particle.startSize = particle.size
    particle.maxLife = particle.life
    
    return particle
end

-- تحديث الجسيمات
local function updateParticles(particles, dt)
    for i = #particles, 1, -1 do
        local p = particles[i]
        
        p.velocity.x = p.velocity.x + p.acceleration.x * dt
        p.velocity.y = p.velocity.y + p.acceleration.y * dt
        p.x = p.x + p.velocity.x * dt
        p.y = p.y + p.velocity.y * dt
        
        p.life = p.life - dt
        
        local lifeRatio = p.life / p.maxLife
        p.color.a = 255 * lifeRatio
        p.size = p.startSize * lifeRatio
        
        -- if p.color.g > 50 then
            -- p.color.g = p.color.g - dt * 200
        -- end
        
        if p.life <= 0 then
            table.remove(particles, i)
        end
    end
end

-- رسم الجسيمات
local function drawParticles(particles, checks)
    for _, p in ipairs(particles) do
        if checks == true then
            love.graphics.setColor(p.color.r, p.color.g, p.color.b, p.color.a)
        end
        love.graphics.circle("fill", p.x, p.y, p.size)
        
        -- if p.color.g > 100 then
            -- love.graphics.setColor(255, 200, 100, p.color.a * 0.4)
            -- love.graphics.circle("fill", p.x, p.y, p.size * 1.8)
        -- end
    end
    love.graphics.setColor(255, 255, 255, 255)
end

-----------------<

function game.start()
    game.player = {
        x = 400,
        y = 300,
        maxSpeed = 300,   -- السرعة القصوى
        currentSpeed = 0, -- السرعة الحالية (تبدأ من 0)
        acceleration = 800, -- معدل التسارع
        deceleration = 600, -- معدل التباطؤ
        image = love.graphics.newImage('Models/Sprites/randomizer1.png'),
        width = 128,
        height = 128,
        rotation = math.pi / 2, -- الزاوية الحالية
        targetRotation = math.pi / 2, -- الزاوية المستهدفة الجديدة
        last_dx = 0,
        last_dy = -1,
        turnSpeed = 5, -- سرعة الدوران
        isMoving = false, -- حالة الحركة
        moveDirX = 0, -- اتجاه الحركة الحالي X
        moveDirY = 0,  -- اتجاه الحركة الحالي Y
        getdown = false,
        ydown = 1,
        hitbox = {
            x = 1,
            y = 3,
            width = 1,
            height = 3
        },
        touched = false,
        once = false
    }

    fireParticles = {}
    smokeParticles = {}
    particleTimer = 0

    game.sounds = {
        walk = love.audio.newSource('Models/Sounds/S1.wav', 'static'),
        explosoin = love.audio.newSource('Models/Sounds/S2.wav', 'static'),
    }

    game.sounds.walk:setPitch(1.4)
    game.sounds.walk:setVolume(0.7)
end

function game.proccess(dt)
    local screenWidth = love.graphics.getWidth()
    local screenHeight = love.graphics.getHeight()
    local margin = -100 -- منطقة خارج الشاشة مسموح بها قبل الإزالة

    if game.player.once == true then 
        game.player.touched = false
    end

    local isFarOutOfScreen = 
        game.player.x + game.player.width < -margin or          -- بعيد خارج اليسار
        game.player.x - game.player.width > screenWidth + margin or -- بعيد خارج اليمين
        game.player.y + game.player.height < -margin or           -- بعيد خارج الأعلى
        game.player.y - game.player.height > screenHeight + margin
    if isFarOutOfScreen and game.player.once == false then
        game.player.once = true
        game.player.getdown = nil
        game.player.touched = true
        game.sounds.explosoin:play()
    end

    if game.player.getdown == true then
        game.player.ydown = game.player.ydown + 15
        game.player.y = game.player.y + game.player.ydown * dt
    elseif game.player.getdown == false then
        local dx, dy = 0, 0
        game.player.isMoving = false -- إعادة تعيين حالة الحركة في كل إطار
        
        -- الحركة العمودية
        if love.keyboard.isDown('w', 'up') then
            dy = dy - 1
            game.player.isMoving = true
            -- createParticleSystem(game.player.x - 15, game.player.y - 15, 15)
            -- updateParticles(dt)
            game.sounds.walk:play()
        end
        if love.keyboard.isDown('s', 'down') then
            dy = dy + 1
            game.player.isMoving = true
            -- createParticleSystem(game.player.x - 15, game.player.y - 15, 15)
            -- updateParticles(dt)
            game.sounds.walk:play()
        end
        
        -- الحركة الأفقية
        if love.keyboard.isDown('a', 'left') then
            dx = dx - 1
            game.player.isMoving = true
            -- createParticleSystem(game.player.x - 15, game.player.y - 15, 15)
            -- updateParticles(dt)
            game.sounds.walk:play()
        end
        if love.keyboard.isDown('d', 'right') then
            dx = dx + 1
            game.player.isMoving = true
            -- createParticleSystem(game.player.x, game.player.y, 15)
            -- updateParticles(dt)
            game.sounds.walk:play()
        end
        
        -- تحديث الزاوية المستهدفة عند الحركة
        if dx ~= 0 or dy ~= 0 then
            game.player.last_dx = dx
            game.player.last_dy = dy
            
            -- حساب الزاوية الجديدة المستهدفة
            game.player.targetRotation = math.atan2(dy, dx) + math.pi / 2
            
            -- تخزين اتجاه الحركة الحالي (متجه طبيعي)
            local length = math.sqrt(dx*dx + dy*dy)
            game.player.moveDirX = dx / length
            game.player.moveDirY = dy / length
        end
        
        -- تطبيق التداخل الزاوي فقط عند الحركة
        if game.player.isMoving then
            game.player.rotation = lerpAngle(
                game.player.rotation,
                game.player.targetRotation,
                game.player.turnSpeed * dt
            )
        end
        
        -- نظام التسارع والتباطؤ
        if game.player.isMoving then
            -- التسارع نحو السرعة القصوى
            game.player.currentSpeed = game.player.currentSpeed + game.player.acceleration * dt
            if game.player.currentSpeed > game.player.maxSpeed then
                game.player.currentSpeed = game.player.maxSpeed
            end
        else
            -- التباطؤ عند التوقف
            game.player.currentSpeed = game.player.currentSpeed - game.player.deceleration * dt
            if game.player.currentSpeed < 0 then
                game.player.currentSpeed = 0
            end
        end
        
        -- تطبيق الحركة إذا كانت السرعة الحالية أكبر من الصفر
        if game.player.currentSpeed > 0 then
            game.player.x = game.player.x + game.player.moveDirX * game.player.currentSpeed * dt
            game.player.y = game.player.y + game.player.moveDirY * game.player.currentSpeed * dt
        end

        clampPlayerPositionWithMargin(game.player, -10)
        -- if particles[1] ~= nil then
            -- updateParticles(dt)
        -- end
    end

    -- ======= تحديث الجسيمات هنا ======= --
    -- إنشاء جسيمات جديدة عند الحركة
    particleTimer = particleTimer + dt
    if game.player.currentSpeed > 0 and particleTimer > emissionRate then
        particleTimer = 0
        if game.player.once == false then
            table.insert(fireParticles, createFireParticle(game.player))
            table.insert(smokeParticles, createSmokeParticle(game.player))
        end
    end
    
    -- تحديث الجسيمات
    updateParticles(fireParticles, dt)
    updateParticles(smokeParticles, dt)

    -- التحقق من خروج الجسيمات خارج الشاشة
    local screenWidth = love.graphics.getWidth()
    local screenHeight = love.graphics.getHeight()
    local margin = 100
    
    for i = #fireParticles, 1, -1 do
        local p = fireParticles[i]
        if p.x < -margin or p.x > screenWidth + margin or 
           p.y < -margin or p.y > screenHeight + margin then
            table.remove(fireParticles, i)
        end
    end
    
    for i = #smokeParticles, 1, -1 do
        local p = smokeParticles[i]
        if p.x < -margin or p.x > screenWidth + margin or 
           p.y < -margin or p.y > screenHeight + margin then
            table.remove(smokeParticles, i)
        end
    end
end

function game.addimage()
    local scaleX = game.player.width / game.player.image:getWidth()
    local scaleY = game.player.height / game.player.image:getHeight()

    love.graphics.draw(
        game.player.image,
        game.player.x,
        game.player.y,
        game.player.rotation,
        scaleX,
        scaleY,
        game.player.image:getWidth() / 2,
        game.player.image:getHeight() / 2
    )

    -- حساب موقع الدائرة مع مراعاة الدوران
    local circleDistance = -15 -- المسافة من مركز اللاعب
    local angle = game.player.rotation - math.pi/2 -- تصحيح الزاوية
    local circleX = game.player.x + math.cos(angle) * circleDistance
    local circleY = game.player.y + math.sin(angle) * circleDistance

    --love.graphics.circle('line', circleX, circleY, 12)
    --love.graphics.circle('line', 350, 50, 1)
    
    -- -- رسم معلومات التسارع (تبقى كما هي)
    love.graphics.setColor(1, 1, 1)
    -- love.graphics.print("Current speed: " .. math.floor(game.player.currentSpeed), 10, 10)
    -- love.graphics.print("Acceleration: " .. game.player.acceleration, 10, 30)
    -- love.graphics.print("Deceleration: " .. game.player.deceleration, 10, 50)

    -- الدخان أولاً (في الخلفية)
    drawParticles(smokeParticles, true)
    -- اللهب فوق الدخان
    drawParticles(fireParticles, true)
end

return game