local rock = {}

rock.rocks = {}
rock.spawnInterval = 2.0  -- الفترة الابتدائية بين إضافة الصخور
rock.minInterval = 0.1    -- الحد الأدنى للفترة بين الإضافات
rock.decreaseAmount = 0.1 -- مقدار النقصان في الفترة عند كل توليد
rock.spawnTimer = 0       -- مؤقت لتتبع الوقت منذ آخر توليد
rock.score = 0

function rock.add()
    -- توليد موضع عشوائي في أعلى الشاشة
    local screenWidth = love.graphics.getWidth()
    local x = love.math.random(0, screenWidth)
    
    -- تحميل الصورة
    local image = love.graphics.newImage('Models/Sprites/randomizer12.png')
    
    -- إنشاء صخرة جديدة
    local newRock = {
        x = x,
        y = -image:getHeight(),
        image = image,
        width = 1,
        height = 1,
        nspeed = 100,
        rspeed = love.math.random(100, 300),
    }
    
    -- إضافة الصخرة إلى الجدول
    table.insert(rock.rocks, newRock)
    
    -- تقليل الفترة الزمنية بين الإضافات
    rock.spawnInterval = math.max(rock.minInterval, rock.spawnInterval - rock.decreaseAmount)

    sounds = {
        score = love.audio.newSource('Models/Sounds/S3.wav', 'static'),
        hit = love.audio.newSource('Models/Sounds/S4.wav', 'static'),
    }
end

function rock.update(dt, player)
    -- تحديث مؤقت التوليد
    rock.spawnTimer = rock.spawnTimer + dt
    
    if rock.spawnTimer >= rock.spawnInterval then
        rock.add()
        rock.spawnTimer = 0
        rock.spawnInterval = math.max(rock.minInterval, rock.spawnInterval - rock.decreaseAmount)
    end
    
    -- تحديث الصخور والتحقق من التصادم
    for i = #rock.rocks, 1, -1 do
        local r = rock.rocks[i]
        r.y = r.y + r.nspeed * dt
        
        -- التحقق من التصادم مع اللاعب
        if checkCircleRectCollision(player, 12, r.x - 5, r.y, r.width + 8, r.height + 8, 0) then
            -- إجراءات عند التصادم
            player.getdown = true
            table.remove(rock.rocks, i)
            sounds.hit:play()
        -- التحقق من خروج الصخرة من الشاشة
        elseif r.y > love.graphics.getHeight() then
            table.remove(rock.rocks, i)
            sounds.score:play()
            rock.score = rock.score + 1
        end
    end
end

function rock.draw()
    -- رسم جميع الصخور
    for i, r in ipairs(rock.rocks) do
        love.graphics.draw(
        r.image,
        r.x,
        r.y,
        0,
        r.width,
        r.height,
        r.image:getWidth() / 2,
        r.image:getHeight() / 2
    )

    --love.graphics.setColor(1,0,0,0.5)
    --love.graphics.rectangle('line', r.x - 5, r.y, r.width + 8, r.height + 8)
    love.graphics.setColor(1,1,1,1)
    love.graphics.print("Score: " .. rock.score, 10, 10)
    end
end

-- دالة للكشف عن التصادم بين دائرة ومستطيل
function checkCircleRectCollision(obj, circleRadius, 
                                 rectX, rectY, rectWidth, rectHeight, rectRotation)

    local circleDistance = -15 -- المسافة من مركز اللاعب
    local angle = obj.rotation - math.pi/2 -- تصحيح الزاوية
    local circleX = obj.x + math.cos(angle) * circleDistance
    local circleY = obj.y + math.sin(angle) * circleDistance

    -- 1. حساب مركز المستطيل
    local rectCenterX = rectX
    local rectCenterY = rectY
    
    -- 2. تحويل إحداثيات الدائرة إلى النظام المحوري للمستطيل (مع مراعاة الدوران)
    local cosAngle = math.cos(-rectRotation)
    local sinAngle = math.sin(-rectRotation)
    
    -- حساب الإحداثيات النسبية للدائرة بالنسبة لمركز المستطيل
    local relX = circleX - rectCenterX
    local relY = circleY - rectCenterY
    
    -- تطبيق الدوران العكسي
    local rotatedX = relX * cosAngle - relY * sinAngle
    local rotatedY = relX * sinAngle + relY * cosAngle
    
    -- 3. إيجاد أقرب نقطة على المستطيل إلى الدائرة (في النظام المحوري)
    local closestX = math.max(-rectWidth/2, math.min(rotatedX, rectWidth/2))
    local closestY = math.max(-rectHeight/2, math.min(rotatedY, rectHeight/2))
    
    -- 4. حساب المسافة بين مركز الدائرة وأقرب نقطة على المستطيل
    local distanceX = rotatedX - closestX
    local distanceY = rotatedY - closestY
    local distanceSquared = distanceX * distanceX + distanceY * distanceY
    
    -- 5. التحقق من التصادم
    return distanceSquared <= (circleRadius * circleRadius)
end

function checkCollider(obj1, obj2)
    -- for 8 directions box!
    local _x = obj1.x - 5
    local _wid = obj1.width + 8
    local _hei = obj1.height + 8
    
    local _x_ = (obj2.x - 35) + (obj2.width / 2)
    local _y_ = (obj2.y - 35) + (obj2.height / 2)

    return _x < _x_ and
    _x + _wid > (obj2.x - 35) and
    obj1.y < _y_ and
    obj1.y + _hei > (obj2.y - 35)
end

function checkCollision(obj1, obj2)
    -- حساب الهوامش الشفافة
    local marginX1 = obj1.width * 0.2  -- تجاهل 20% من الحواف
    local marginY1 = obj1.height * 0.2
    local marginX2 = obj2.width * 0.2
    local marginY2 = obj2.height * 0.2
    
    -- إنشاء مستطيلات تصادم مصغرة
    local collisionX = (obj1.x + marginX1) < (obj2.x + obj2.width - marginX2) and
                      (obj1.x + obj1.width - marginX1) > (obj2.x + marginX2)
    
    local collisionY = (obj1.y + marginY1) < (obj2.y + obj2.height - marginY2) and
                      (obj1.y + obj1.height - marginY1) > (obj2.y + marginY2)
    
    return collisionX and collisionY
end

function circleCollision(obj1, obj2)
    -- حساب مراكز الأجسام
    local cx1 = obj1.x + obj1.width/2
    local cy1 = obj1.y + obj1.height/2
    local cx2 = obj2.x + obj2.width/2
    local cy2 = obj2.y + obj2.height/2
    
    -- حساب المسافة بين المراكز
    local distance = math.sqrt((cx2 - cx1)^2 + (cy2 - cy1)^2)
    
    -- حساب نصف القطر الفعال (أصغر من الحجم الفعلي)
    local radius1 = math.min(obj1.width, obj1.height) * 0.4
    local radius2 = math.min(obj2.width, obj2.height) * 0.4
    
    -- التصادم يحدث إذا كانت المسافة < مجموع نصفي القطر
    return distance < (radius1 + radius2)
end

function pixelPerfectCollision(obj1, obj2)
    -- أولاً: تحقق بالطريقة البسيطة لتوفير الوقت
    if not checkCollision(obj1, obj2) then
        return false
    end
    
    -- ثانياً: تحدد منطقة التداخل
    local overlapX1 = math.max(obj1.x, obj2.x)
    local overlapY1 = math.max(obj1.y, obj2.y)
    local overlapX2 = math.min(obj1.x + obj1.width, obj2.x + obj2.width)
    local overlapY2 = math.min(obj1.y + obj1.height, obj2.y + obj2.height)
    
    -- التحقق من وجود الصور
    if not obj1.image or not obj2.image then
        return false
    end
    
    -- التحميل المؤجل لبيانات الصورة
    if not obj1.imageData then
        -- التحقق من أن الصورة محملة بشكل صحيح
        if obj1.image:typeOf("Image") then
            obj1.imageData = obj1.image:getData()
        else
            print("خطأ: الكائن 1 ليس صورة صالحة")
            return false
        end
    end
    
    -- نفس الشيء للكائن 2
    if not obj2.imageData then
        if obj2.image:typeOf("Image") then
            obj2.imageData = obj2.image:getData()
        else
            print("خطأ: الكائن 2 ليس صورة صالحة")
            return false
        end
    end
    
    -- تحقق من كل بكسل في منطقة التداخل
    for y = overlapY1, overlapY2 do
        for x = overlapX1, overlapX2 do
            -- الإحداثيات النسبية داخل الكائن 1
            local relX1 = math.floor(x - obj1.x)
            local relY1 = math.floor(y - obj1.y)
            
            -- الإحداثيات النسبية داخل الكائن 2
            local relX2 = math.floor(x - obj2.x)
            local relY2 = math.floor(y - obj2.y)
            
            -- تأكد من أن الإحداثيات ضمن حدود الصورة
            if relX1 >= 0 and relX1 < obj1.width and relY1 >= 0 and relY1 < obj1.height then
                if relX2 >= 0 and relX2 < obj2.width and relY2 >= 0 and relY2 < obj2.height then
                    -- احصل على قيمة الشفافية (قناة alpha)
                    local _, _, _, a1 = obj1.imageData:getPixel(relX1, relY1)
                    local _, _, _, a2 = obj2.imageData:getPixel(relX2, relY2)
                    
                    -- إذا كان كلا البكسلين غير شفافين تماماً
                    if a1 > 0.01 and a2 > 0.01 then
                        return true
                    end
                end
            end
        end
    end
    
    return false
end

return rock