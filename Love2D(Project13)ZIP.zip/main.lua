local ship
local metros

local particles = {}
local gravity = 80 -- جاذبية
local stopcode = false

function createParticleSystem(x, y, count)
    for i = 1, count do
        local particle = {
            x = x,
            y = y,
            size = love.math.random(5, 15), -- حجم الجسيم
            startSize = 0, -- سيتم تعيينه لاحقاً
            life = love.math.random(1.0, 2.0), -- العمر
            maxLife = 0, -- سيتم تعيينه لاحقاً
            color = {
                r = love.math.random(100, 255),
                g = love.math.random(100, 255),
                b = love.math.random(0, 0),
                a = 255 -- شفافية البداية
            },
            velocity = {
                x = love.math.random(-220, 220),
                y = love.math.random(-120, 120) -- تبدأ بالتحرك للأعلى
            },
            acceleration = {
                x = 0,
                y = gravity
            }
        }
        
        -- حفظ القيم الأولية للاستخدام في التلاشي
        particle.startSize = particle.size
        particle.maxLife = particle.life
        
        table.insert(particles, particle)
    end
end

function updateParticles(dt)
    for i = #particles, 1, -1 do
        local p = particles[i]
        
        -- تحديث الموقع والسرعة
        p.velocity.x = p.velocity.x + p.acceleration.x * dt
        p.velocity.y = p.velocity.y + p.acceleration.y * dt
        p.x = p.x + p.velocity.x * dt
        p.y = p.y + p.velocity.y * dt
        
        -- تحديث العمر والتلاشي
        p.life = p.life - dt
        
        -- حساب التغيرات التدريجية
        local lifeRatio = p.life / p.maxLife
        
        -- 1. تلاشي الشفافية تدريجياً
        p.color.a = 255 * lifeRatio
        
        -- 2. تصغير الحجم تدريجياً
        p.size = p.startSize * lifeRatio
        
        -- 3. تغيير اللون تدريجياً (اختياري)
        -- p.color.g = 50 + 150 * lifeRatio
        
        -- إزالة الجسيمات بعد انتهاء عمرها تماماً
        if p.life <= 0 then
            table.remove(particles, i)
        end
    end
end

function drawParticles()
    for _, p in ipairs(particles) do
        -- تعيين اللون مع الشفافية الحالية
        love.graphics.setColor(p.color.r, p.color.g, p.color.b, p.color.a)
        
        -- رسم الدائرة
        love.graphics.circle("fill", p.x, p.y, p.size)
        
        -- إضافة توهج خفيف (اختياري)
        -- if p.size > 3 then
            -- love.graphics.setColor(p.color.r, p.color.g, p.color.b, p.color.a * 0.3)
            -- love.graphics.circle("fill", p.x, p.y, p.size * 1.5)
        -- end
    end
    love.graphics.setColor(255, 255, 255, 255) -- إعادة تعيين اللون
end

function loadlevel()
    -- platform.load()
    -- تحميل صورة الخلفية
    background = love.graphics.newImage('Models/Sprites/randomizer2.png')
    
    -- الحصول على أبعاد الصورة الأصلية
    bgWidth = background:getWidth()
    bgHeight = background:getHeight()
    
    ship = require('Scripts/ship')
    metros = require('Scripts/rocks')

    ship.start()
    metros.add()
    stopcode = false
end

function love.load()
    loadlevel()
end

function love.update(dt)
    -- platform.update(dt)
    if stopcode == true then return end
    ship.proccess(dt)
    if ship.player.once == false then
        metros.update(dt, ship.player)
    end
    updateParticles(dt)

    if ship.player.touched then
        createParticleSystem(ship.player.x, ship.player.y - 25, 100)
    end
end

function love.keypressed(k)
    -- platform.keypressed(k)
    if k == 'r' then
        stopcode = true
        ship.player = nil
        for i = #metros.rocks, 1, -1 do
            local r = metros.rocks[i]
            table.remove(metros.rocks, i)
        end
        metros.spawnInterval = 2.0
        metros.minInterval = 0.1
        metros.decreaseAmount = 0.1
        metros.spawnTimer = 0
        metros.score = 0
        metros.score = 0
        loadlevel()
    end
end

function love.draw()
    if stopcode == true then return end
    ----------------------->
    -- الحصول على أبعاد الشاشة
    local screenWidth = love.graphics.getWidth()
    local screenHeight = love.graphics.getHeight()
    
    -- حساب عدد مرات التكرار المطلوبة
    local repetitionsX = math.ceil(screenWidth / bgWidth) + 1
    local repetitionsY = math.ceil(screenHeight / bgHeight) + 1
    
    -- رسم الخلفية المتكررة
    love.graphics.setColor(1, 1, 1)
    for y = 0, repetitionsY do
        for x = 0, repetitionsX do
            love.graphics.draw(
                background,
                x * bgWidth,  -- الموضع الأفقي
                y * bgHeight  -- الموضع الرأسي
            )
        end
    end
    -----------------------<
    -- platform.draw()
    ship.addimage()
    metros.draw()
    drawParticles()
    if ship.player.touched then
        love.graphics.print('hi', 10, 170)
    end
end