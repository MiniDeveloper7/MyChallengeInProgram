import { Game } from './Game.js';

const config = {
    type: Phaser.AUTO,
    title: 'Project13(Void)',
    description: '',
    parent: 'game-container',
    width: 600,
    height: 600,
    backgroundColor: '#000000',
    pixelArt: false,
    scene: [
        Game,
    ],
    scale: {
        mode: Phaser.Scale.NONE,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
    physics: {
        // default: 'arcade',
        // arcade: {
        //     gravity: { y: 0 },
        //     debug: true,
        // }
        default: 'matter',
        matter: {
            gravity: { y: 0 },
            debug: true,
        }
    },
}

new Phaser.Game(config);

// // في ملف إعدادات اللعبة الرئيسي (ربما main.js أو index.js)
// const config = {
//     type: Phaser.AUTO,
//     width: 600,
//     height: 600,
//     backgroundColor: '#000000',
//     scene: [
//         Game
//     ],
//     scale: {
//         mode: Phaser.Scale.NONE, // للحفاظ على الحجم الثابت
//         autoCenter: Phaser.Scale.CENTER_BOTH
//     },
//     physics: { // أضف هذا الجزء!
//         default: 'arcade', // نحدد استخدام نظام الفيزياء Arcade Physics
//         arcade: {
//             // debug: true, // اختياري: لعرض مستطيلات تصادم الكائنات للمساعدة في التصحيح
//             gravity: { y: 0 } // لا يوجد جاذبية افتراضية في الألعاب ثنائية الأبعاد العلوية/السفلية
//         }
//     }
// };

// new Phaser.Game(config);
            