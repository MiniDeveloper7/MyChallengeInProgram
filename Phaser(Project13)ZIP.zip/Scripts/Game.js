export class Game extends Phaser.Scene {
    static CATEGORY_PLAYER;
    static CATEGORY_ROCK;
    static CATEGORY_WORLD_BOUNDS;

    constructor() {
        super({ key: 'Game' });
        this.Cursors = null;
        this.MaxSpeed = 5;
        this.Speed = 0;
        this.GainSpeed = 0.1;
        this.RotationSpeed = 0.1;

        this.IsAlive = true;
        this.Once = false;
        
        this.SingleRock = null;
        this.RockSpeed = 10;
        this.RockObject = [];

        this.SpawnDelay = 5000;
        this.RockSpawnEvent = null;

        this.Score = 0;
        this.ScoreText = null;
        this.ResetText = null;

        this.StopProccess = false;
    }

    preload() {
        this.load.image('background', 'Models/Sprites/randomizer2.png');
        this.load.image('player', 'Models/Sprites/randomizer1.png');
        this.load.image('rock', 'Models/Sprites/randomizer10.png');

        this.load.audio('s1', 'Models/Sounds/S1.wav');
        this.load.audio('s2', 'Models/Sounds/S2.wav');
        this.load.audio('s3', 'Models/Sounds/S3.wav');
        this.load.audio('s4', 'Models/Sounds/S4.wav');
    }

    create() {
        this.Cursors = null;
        this.MaxSpeed = 5;
        this.Speed = 0;
        this.GainSpeed = 0.1;
        this.RotationSpeed = 0.1;
        this.IsAlive = true;
        this.Once = false;
        this.SingleRock = null;
        this.RockSpeed = 10;
        this.RockObject = [];
        this.SpawnDelay = 5000;
        this.RockSpawnEvent = null;
        this.Score = 0;
        this.ScoreText = null;
        this.StopProccess = false;
        //--------reset args------\\
        
        if (Game.CATEGORY_PLAYER === undefined) {
            Game.CATEGORY_PLAYER = this.matter.world.nextCategory();
            Game.CATEGORY_ROCK = this.matter.world.nextCategory();
            Game.CATEGORY_WORLD_BOUNDS = this.matter.world.nextCategory();
            this.CATEGORY_PLAYER = this.matter.world.nextCategory();
            this.CATEGORY_ROCK = this.matter.world.nextCategory();
            this.CATEGORY_WORLD_BOUNDS = this.matter.world.nextCategory();
        }

        this.background = this.add.tileSprite(640, 360, 1280, 720, 'background');

        const player = this.matter.add.image(640, 360, 'player', null, {
            frictionAir: 0.05,
            mass: 1,
            bounce: 0,
            isFixedRotation: true,
            shape: {
                type: 'rectangle',
                width: 10,
                height: 15,
            }
        });
        player.setBounce(0);
        player.setFixedRotation();
        player.x = 50;
        player.setOrigin(0.5, 0.65);
        player.setCollisionCategory(this.CATEGORY_PLAYER);
        player.setCollidesWith([this.CATEGORY_ROCK, this.CATEGORY_WORLD_BOUNDS]);
        this.player = player;

        this.Cursors = this.input.keyboard.addKeys({
            up: Phaser.Input.Keyboard.KeyCodes.W,
            down: Phaser.Input.Keyboard.KeyCodes.S,
            left: Phaser.Input.Keyboard.KeyCodes.A,
            right: Phaser.Input.Keyboard.KeyCodes.D,
            arrowup: Phaser.Input.Keyboard.KeyCodes.UP,
            arrowdown: Phaser.Input.Keyboard.KeyCodes.DOWN,
            arrowleft: Phaser.Input.Keyboard.KeyCodes.LEFT,
            arrowright: Phaser.Input.Keyboard.KeyCodes.RIGHT,
        });

        this.ScoreText = this.add.text(
            5,
            5,
            'Score: 0',
            {
                fontSize: '18px',
                fill: '#fff',
                fontFamily: 'MyFont'
            }
        );

        this.ResetText = this.add.text(
            5,
            25,
            'R',
            {
                fontSize: '18px',
                fill: '#fff',
                fontFamily: 'MyFont'
            }
        );

        this.matter.world.setBounds(0, 0, this.game.config.width, this.game.config.height, 1, true, true, true, true);
        this.matter.world.walls.left.collisionFilter.category = this.CATEGORY_WORLD_BOUNDS;
        this.matter.world.walls.right.collisionFilter.category = this.CATEGORY_WORLD_BOUNDS;
        this.matter.world.walls.top.collisionFilter.category = this.CATEGORY_WORLD_BOUNDS;
        this.matter.world.walls.bottom.collisionFilter.category = this.CATEGORY_WORLD_BOUNDS;

        if (this.RockSpawnEvent) {
            this.RockSpawnEvent.remove();
        }
        this.RockSpawnEvent = this.time.addEvent({
            delay: this.SpawnDelay,
            callback: this.spawnnewrock,
            callbackScope: this,
            loop: true
        });
    
        this.matter.world.on('collisionstart', (event, bodyA, bodyB) => {
            const gameObjectA = bodyA.gameObject;
            const gameObjectB = bodyB.gameObject;

            // console.log("Collision detected!");
            // console.log("Body A:", gameObjectA ? gameObjectA.texture.key : bodyA.label, "Category:", bodyA.collisionFilter.category);
            // console.log("Body B:", gameObjectB ? gameObjectB.texture.key : bodyB.label, "Category:", bodyB.collisionFilter.category);
            // console.log("---------------------------------------");

            let isPlayerRockCollision = false;
            let playerObject = null;
            let rockObject = null;

            if (gameObjectA === this.player && this.RockObject.includes(gameObjectB)) {
                isPlayerRockCollision = true;
                playerObject = gameObjectA;
                rockObject = gameObjectB;
            } 
            else if (gameObjectB === this.player && this.RockObject.includes(gameObjectA)) {
                isPlayerRockCollision = true;
                playerObject = gameObjectB;
                rockObject = gameObjectA;
            }

            if (isPlayerRockCollision) {
                this.handlePlayerRockOverlap(playerObject, rockObject);
            }
        });

        this.rKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);
        this.rKey.on('down', () => {
            this.IsAlive = false;
            this.StopProccess = true;
            for (let i = 0; i < this.RockObject.length; i++) {
                const rock = this.RockObject[i];
                rock.destroy();
                this.RockObject.splice(i, 1);
                i--;
            }
            player.destroy();
            this.scene.restart();
        });
    
        this.ResetText.setText('Press R to reset');
    }

    spawnnewrock() {
        if (!this.IsAlive) {
            return;
        }
        const x = Phaser.Math.Between(20, 580);
        const newRock = this.matter.add.image(x, -50, 'rock', null, {
            frictionAir: 0.01,
            density: 0.001,
            isStatic: false,
            shape: {
                type: 'circle',
                radius: 5
            },
            rotationSpeed: Phaser.Math.Between(-0.01, 0.01)
        });
        newRock.setCollisionCategory(this.CATEGORY_ROCK);
        newRock.setCollidesWith(this.CATEGORY_PLAYER);
        newRock.setOrigin(0.5, 0.6);
        
        newRock.setVelocityY(this.RockSpeed);

        this.RockObject.push(newRock);

        if (this.SpawnDelay > 1000) {
            this.SpawnDelay -= 500;
        } else if (this.SpawnDelay <= 1000 && this.SpawnDelay > 100) {
            this.SpawnDelay -= 100;
        } else if (this.SpawnDelay <= 100 && this.SpawnDelay >= 75) {
            this.SpawnDelay -= 5;
        }
        this.RockSpawnEvent.delay = this.SpawnDelay;
    }

    increaseScore(amount, scoretype) {
        if (this.IsAlive) {
            if (scoretype == 'p') {
                this.Score += amount;
            } else if (scoretype == 's') {
                this.Score = amount;
            }
            this.ScoreText.setText('Score: ' + this.Score);
        }
    }

    handlePlayerRockOverlap(player, rock) {
        rock.destroy();
        this.sound.play('s4', { volume: 0.2 });

        const index = this.RockObject.indexOf(rock);
        if (index > -1) {
            this.RockObject.splice(index, 1);
        }
        this.IsAlive = false;
        this.destroyPlayer();
    }

    destroyPlayer() {
        if (!this.player || this.StopProccess) {
            return;
        }
        const tweenNumber = 20;
        this.StopProccess = true;
        this.player.setVelocityY(tweenNumber);
        this.player.setCollidesWith([this.CATEGORY_ROCK]);
    }

    flyParticle() {
        const mycolor = Phaser.Display.Color.RGBToString(200, 20, 0);
        const graphics = this.add.graphics();
        graphics.fillStyle(0xffffff, 1);
        graphics.fillRect(0, 0, 10, 10);
        graphics.generateTexture('particle_square', 10, 10);
        graphics.destroy();
        const emitter = this.add.particles(0, 0, 'particle_square', {
            tint: [
                '0x' + mycolor.split('#')[1]
                ],
            speed: { min: -200, max: 200 },
            angle: { min: 0, max: 360 },
            scale: { start: 0.5, end: 0 },
            alpha: { start: 1, end: 0 },
            lifespan: 1000,
            gravityY: 0,
            quantity: 6,
            blendMode: 'ADD'
        });
        emitter.explode(6, this.player.x, this.player.y);
    }

    update() {
        for (let i = 0; i < this.RockObject.length; i++) {
            const rock = this.RockObject[i];
            if (rock.y > this.game.config.height + 50) {
                rock.destroy();
                this.RockObject.splice(i, 1);
                i--;
                this.increaseScore(1, 'p');
                if (this.IsAlive && !this.StopProccess) {
                    this.sound.play('s3', { volume: 0.4 });
                }
            }
        }

        if (Math.round(this.player.y) >= 600 && !this.Once) {
            this.Once = true;
            this.sound.play('s2', { volume: 0.2 });
            const mycolor = Phaser.Display.Color.RGBToString(200, 100, 0);
            const graphics = this.add.graphics();
            graphics.fillStyle(0xffffff, 1);
            graphics.fillRect(0, 0, 10, 10);
            graphics.generateTexture('particle_square', 10, 10);
            graphics.destroy();
            
            const emitter = this.add.particles(0, 0, 'particle_square', {
                tint: [
                    '0x' + mycolor.split('#')[1]
                    ],
                speed: { min: -200, max: 200 },
                angle: { min: 0, max: 360 },
                scale: { start: 1, end: 0 },
                alpha: { start: 1, end: 0 },
                lifespan: 3000,
                gravityY: 0,
                quantity: 100,
                blendMode: 'ADD'
            });
            emitter.explode(100, this.player.x, this.player.y);
        }

        if (this.StopProccess) {
            this.player.y += 1
        }

        if (this.StopProccess) {
            return;
        }
        let velocityX = 0;
        let velocityY = 0;

        if (this.Cursors.left.isDown || this.Cursors.arrowleft.isDown) {
            velocityX = -1;
        } else if (this.Cursors.right.isDown || this.Cursors.arrowright.isDown) {
            velocityX = 1;
        }

        if (this.Cursors.up.isDown || this.Cursors.arrowup.isDown) {
            velocityY = -1;
        } else if (this.Cursors.down.isDown || this.Cursors.arrowdown.isDown) {
            velocityY = 1;
        }

        if (velocityX !== 0 || velocityY !== 0) {
            const magnitude = Math.sqrt(velocityX * velocityX + velocityY * velocityY);
            const normalizedVelocityX = velocityX / magnitude;
            const normalizedVelocityY = velocityY / magnitude;
            this.norX = normalizedVelocityX
            this.norY = normalizedVelocityY

            this.Speed += this.GainSpeed;
            this.Speed = Phaser.Math.Clamp(this.Speed, 0, this.MaxSpeed);
            this.player.setVelocity(normalizedVelocityX * this.Speed, normalizedVelocityY * this.Speed);
            this.flyParticle();
            this.sound.play('s1', {
                volume: 0.01,
                rate: 0.6
                });

            const targetAngle = Math.atan2(normalizedVelocityY, normalizedVelocityX) + Math.PI / 2;
            this.player.setRotation(
                Phaser.Math.Angle.RotateTo(
                    this.player.rotation,
                    targetAngle,
                    this.RotationSpeed
                )
            );
        } else {
            const currentNorX = this.norX || 0;
            const currentNorY = this.norY || 0;

            if (this.Speed > 0) {
                this.Speed -= this.GainSpeed;
            }
            this.Speed = Phaser.Math.Clamp(this.Speed, 0, this.MaxSpeed);
            this.player.setVelocity(currentNorX * this.Speed, currentNorY * this.Speed);
        }
    }
}
